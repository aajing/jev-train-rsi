# jev-train-rsi 数据规范

本规范定义一项有限范围的研究任务：让一个尚未做决策微调的 Qwen3-4B-Base，通过合成数据与训练策略优化，提高对明确规则问题的直接作答能力。它针对 JEV 所讨论的算术、状态跟踪和规则推理弱项，不代表 JEV 全部业务领域，也不测通用语言生成能力。

这些内容是拟采用的任务定义。个人信息按贡献者要求保留 TODO；没有进行 GPU 训练，没有已测 baseline 分数或训练耗时。

## 模型和任务形式

- 学生：`Qwen/Qwen3-4B-Base`，固定版本 `906bfd4b4dc7f14ee4320094d8b41684abff8539`。
- 合成教师：[官方 Qwen3.8-27B](https://huggingface.co/Qwen/Qwen3.8-27B/tree/1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0)，固定版本 `1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0`。教师可选；也允许纯程序合成。使用其原生聊天模板和支持 Qwen3.8 的生成实现，只发送文本输入。该 3.8 checkpoint 官方配置使用 `Qwen3_5ForConditionalGeneration` 架构名，环境应按此配置加载；仓库与权重版本仍固定为 Qwen3.8-27B。
- 教师权重冻结，使用发布的 BF16 权重，原有 FP32 张量保持原精度。[权重索引](https://huggingface.co/Qwen/Qwen3.8-27B/blob/1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0/model.safetensors.index.json) 中的完整权重总计 55,562,855,904 字节，约 55.56 GB；单张 H100 80GB 上先运行教师合成，卸载教师后再加载学生训练。实际显存峰值、批量与吞吐仍需验证。
- 输入只有状态与问题，不给候选项；学生自回归生成答案。允许先解释或推理，最后用固定一行提交最终答案。
- 英文输入，固定模板；不将 group ID、domain、正确答案、来源、生成种子等审计信息拼进输入。
- 评测固定 greedy 解码，`do_sample=false`、`num_beams=1`、最多 512 个新 tokens，按原模型 EOS 停止。测试时只运行学生，不能调用教师、工具或检索。
- `Final answer: <JSON scalar>` 必须是输出的最后非空行，从行首开始且冒号后有空格；整个输出只允许出现一次 `Final answer:` 前缀，解释中也不能重复。标量只允许布尔值、整数、字符串；解析时比较类型和值。前面的解释不单独评分。

## 可以改动的范围

| 部分 | 允许改动 |
| --- | --- |
| 数据合成 | 合法 ID 状态的采样程序、教师提示词、难度与边界样本比例 |
| 数据处理 | 筛选、去重、配比、权重、训练课程、可选推理过程监督 |
| 训练 | 训练代码、损失、优化器、学习率、批量、训练步数；可选全参数训练或标准 LoRA |
| 模型参数 | 在同一初始基座上，通过上述合法训练更新学生权重 |

固定初始 checkpoint、模型结构、tokenizer、教师权重、训练数据支持范围、资源预算、评测数据、题目语义、评测输入、解码与评分程序。LoRA 必须能合并到已有线性权重，不能添加新的推理模块。每个候选重新从同一基座开始。控制组的固定 LoRA 配方不限制其他候选。

## 数据来源

主来源是 [Open-Jev](https://github.com/Zefan-Cai/Open-Jev/tree/3308a15ccd7eea1df7a37d6ddc39b023b801ba16) 的 `reasoning-control-v1`。其 `jev/case_reasoning.py` 提供七类程序生成器和精确答案计算函数，代码为 MIT，生成数据声明为 CC0-1.0。

发布方的原始配置为 `groups=2500, seed=76109`。每个场景同时生成 choice、noul 和 score；本任务取主问题对应的状态和问题，将 builder 的原生答案转为 JSON 标量，移除原选择题的 options/target 字段。不使用验证题和序数辅助题，并始终按场景划分。上游源码保持原样，派生数据采用自由回答格式。

上游主问题场景数量如下，尚未应用本任务的规范化去重：

| 领域 | train | calibration | validation | test | 上游 OOD |
| --- | ---: | ---: | ---: | ---: | ---: |
| 布尔逻辑 | 254 | 24 | 15 | 29 | 36 |
| 有向图关系 | 251 | 14 | 19 | 38 | 35 |
| 整数算术 | 277 | 12 | 12 | 20 | 36 |
| 时区时间排序 | 257 | 17 | 12 | 35 | 36 |
| 受限程序执行 | 267 | 12 | 15 | 28 | 35 |
| 列表算法 | 239 | 15 | 14 | 53 | 36 |
| 规则化证据整合 | 269 | 16 | 12 | 24 | 36 |
| 合计 | 1814 | 110 | 99 | 227 | 250 |

训练种子来自 train；validation 与 calibration 合并为开发集，本任务不另外使用它拟合温度。原始 test/OOD 作为公开参考记录，不参加训练，也不是本任务的秘密测试。实际构建已完成：训练集规范化去重后为 **1800 条**（布尔逻辑从 254 减为 240，其余不变），开发集 **209 条**，公开参考 **477 条**。删除的 14 条包括 7 条训练内部重复、4 条与 test 重复、2 条与 calibration 重复、1 条与 validation 重复。正式 Judge 另有 **2800 条**，各领域及条件恰好 200 条。`data_manifest.json` 记录交付数量和文件哈希。

## 七类题的训练和评测范围

候选可以改变允许范围内的参数分布、边界样本比例、难例选择和训练课程，但不能把下面“更难结构测试”的范围用作训练数据。可信组件从合法结构化参数重新构建问题并计算最终答案。教师可以提供可选的推理过程用于训练，但它不是经过验证的推导，也不能覆盖 oracle 的最终标签。

| 领域 | 允许的训练状态和固定答案规则 | 同范围测试 | 更难结构测试 |
| --- | --- | --- | --- |
| 布尔逻辑 | 四个布尔变量；深度为 2 的表达式树；运算 AND、OR、NOT；叶子为已声明变量。使用 `eval_boolean` 递归求值。 | 新赋值、新表达式、新名称 | 五变量、深度 3，并包含 XOR、IMPLIES |
| 有向图关系 | 五个节点，无自环或重复边；不同起终点。判断直达、间接可达或不可达，直达优先。使用 `graph_distances` 的 BFS。 | 新图和起终点 | 八节点、不同边密度 |
| 整数算术 | `a ∈ [-40,40]`，`b ∈ [1,17]`，`c ∈ [-20,20]`；表达式只能为 `(a*b)+c`、`(a-b)*c`、`a+(b*c)`。使用受限 AST 的 `arithmetic_value`。 | 新数值和表达式组合 | 更大数值，整除、余数、abs/min/max 等上游保留表达式 |
| 时区时间排序 | 四个互不相同的事件；相对 2026-02-14 12:00 UTC 的偏移为 -180 至 180 分钟；UTC 偏移只能为 -480、-180、0、120、540 分钟。最早或最晚事件唯一。使用 `utc_order`。 | 新时间、事件顺序和时区组合 | 五事件，跨闰日、非整小时 UTC 偏移 |
| 受限程序执行 | 初始值 -15 至 15，四个输入整数 -9 至 12，条件 `item > threshold` 且 threshold 为 -3 至 5，调整量 1 至 6，最终乘数 -4 至 5。固定 for/if 骨架，用 `program_value` 的受限解释器求最终整数。 | 新合法参数和列表 | 六项列表、取模条件 |
| 列表算法 | 六个不重复整数，取自 -40 至 40；保留能被 2 整除的值，升序排列，取索引 0 至 3；不足时答案为 not_present。使用 `algorithm_result`。 | 新列表和索引 | 十一项列表、除数 3/4/5、降序、索引至 5 |
| 规则化证据整合 | 使用上游 ID 状态结构：目标实体和无关实体；状态值 queued/active/paused/closed；版本、权威性、撤销标记；无别名链。忽略无关、非权威、已撤销记录，取最高有效版本；同版冲突返回 conflict，无有效记录返回 not_stated。使用 `resolve_evidence`。 | 新记录值、排列和权威/撤销组合 | 两跳实体别名链 |

完整训练支持集以固定源码 `BUILDERS[domain](rng, tag, ood=False)` 能产生的状态为准，允许规范化随机标识；表中的范围不授权添加新的状态结构。证据题具体保留三条版本 1/2/3 记录、可选的第二条版本 3 权威未撤销记录，以及上游固定的两条无关/非权威干扰记录，共 5 或 6 条。问题语义与最终答案由上游 builder/oracle 固定。派生输入完全删除候选项、字母序号及干扰答案，整数题必须直接生成整数。

训练种子的原始分布保持上游设定，B1 仅按领域配平；正式评测按下面的固定情况配额重采样。这里的 ID 表示状态仍在训练支持范围内，不承诺答案频率等同于上游自然分布。候选可在允许范围内重新分配训练概率。训练前校验结构与范围；固定 renderer 保证题目与状态含义一致。自由自然语言改写不属于第一版允许空间。

## 合成接口

第一版允许两条路径，使用相同的最终校验接口：

1. 程序直接提出领域、结构化参数和实例。
2. 本地官方 Qwen3.8-27B 根据候选设计的提示词提出同样的结构化参数和实例。

输入固定接口后，任务组件校验 schema 和训练范围，调用对应 oracle，生成唯一的语义答案，再渲染状态和问题。教师或 Agent 声明的答案不具有权威性；可选解释文本可作为候选自己的训练材料，但最终答案必须由 oracle 计算。失败、重复、越界和重试都计预算。

已有 CPU 数据构建器将固定源码场景转为直接作答记录，并提供固定答案协议。任意候选状态的通用接入校验、训练器与模型评测包装仍属于 Harbor 构建工作；不能把任意自由文本视为已能验证答案。

答案类型固定如下，测试输入不展示任何候选列表：

| 领域 | 输出类型及例子 |
| --- | --- |
| 布尔逻辑 | JSON 布尔值，如 `true` |
| 有向图关系 | 语义字符串，如 `"indirect"`；按题意判断 direct/indirect/unreachable |
| 算术、程序执行 | JSON 整数，如 `14`、`-27` |
| 时间排序 | 事件 ID 字符串，如 `"event_SCENE_2"` |
| 列表算法 | 整数；不存在时为 `"not_present"` |
| 证据整合 | 状态字符串；同版冲突为 `"conflict"`，无有效证据为 `"not_stated"` |

下面是本说明构造的算术样本：

```json
{
  "kind": "free_response",
  "state": {
    "values": {"a": 3, "b": 4, "c": 2},
    "expression": "(a * b) + c",
    "semantics": "Use exact integer arithmetic."
  },
  "question": "Calculate the exact expression result.",
  "answer": 14,
  "domain": "arithmetic",
  "regime": "id"
}
```

模型只看到固定指令、状态和问题；`answer` 用于监督，domain/regime 等用于审计和分层评分。例如它可以输出：

```text
3 times 4 is 12; adding 2 gives 14.
Final answer: 14
```

也可以仅输出 `Final answer: 14`，两者的得分相同。输出 `Final answer: "14"` 则类型错误；从解释中的数字或多个答案中挑出正确值不算作答成功。标准控制组仅监督最终答案行与 EOS，候选可增加解释监督；所有训练文本均计入 token 预算。

实际输入模板以 `scripts/materialize_data.py:render_ascii_prompt` 为准，以 `[response]` 结束。最大输入长度 4096 tokens，输出上限另计。禁止静默截断输入；超长合成样本计一次失败并拒绝。Judge 输入长度仍须用实际 tokenizer 验证。

## 数据划分和防泄漏

- 训练：去重后的官方 train 种子，加上符合 ID 合同的新合成数据。
- 开发：官方 validation 与 calibration 的主问题转换后合并、规范化去重；可看逐题结果，用于选择和诊断，不可做梯度训练。
- 公开参考：官方 test 和 OOD 主问题的直接作答版本；排除出训练。文件及官方种子原本公开，不能宣称其保密。
- Formal Judge: generated with the same fixed source and an independent construction seed; 2,800 unique normalized scenes are frozen before experiments, with 200 ID and 200 shifted scenes per domain. Native oracles supply the labels. The original frozen records and seed are now publicly delivered but enter Judge only at runtime.
- 每个 Judge 场景生成一次答案，共 2800 次自回归评测。B0、B1 与所有候选使用相同输入、解码和答案解析规则。模型评测包装器尚未实现。
- Check exact input overlap between the original training, development and reference splits, and between those splits and Judge, after removing record IDs and normalizing generated scene names. The key contains only kind/state/question, never answer. This is neither semantic deduplication nor proof of complete contamination exclusion. Subsequent public delivery of evaluation records does not change these splits.
- 为避免后续大量合成时偶然撞到测试题，对上述规范化输入 SHA256 定义 `bucket = int(hash[:8], 16) % 10`。新训练状态只接受 bucket 0 至 7；正式 Judge 只取 bucket 8 至 9。固定的 1800 条训练种子是唯一例外，但它们已全部从 Judge 排除。新状态仍须排除开发/公开参考的精确重复。这个公开分区规则用于隔离精确输入，不宣称能阻止任意测试重建。
- 同一场景及其输入改写或增强版本必须保留共同 lineage，不能借新 ID 重置样本数或成本。

Frozen evaluation records and the original construction seed are publicly delivered for task construction and review. See [evaluation asset delivery](EVALUATION_ASSETS.md) for the complete source attachment, dedicated unencrypted evaluation ZIP and raw downloads. `evaluation-assets/data/private/` is the public delivery location; `data/private/` inside the ZIP is the installation layout. The legacy directory name does not imply secrecy in a public repository. Private-distribution and unpublished-seed statements in the original seed, manifests and audits remain historical metadata; the current delivery document supersedes their distribution restrictions.

Provision Work from an explicit allowlist excluding `evaluation-assets/`, `data/private/`, complete attachments under `dist/`, and bundled `.git/` history. Evaluation assets enter Judge only at runtime. Research runs remain offline and must not access, download, reconstruct, memorize or train on held-out records, or probe their construction seed. Public delivery increases prior-contamination and memorization risk; global secrecy and prior-unseen-data guarantees are not claimed. Judge feedback still returns only the specified aggregates, never per-example responses or correctness.

## 评测分层配额

每个领域的 ID 和结构变化测试分别采用下表配额，每个单元仍为 200 题。答案类别只用于出题方筛选与统计，不拼进模型输入，也不提供候选答案列表。

| 领域 | 每种测试条件内的固定配额 |
| --- | --- |
| 布尔逻辑 | true 100，false 100 |
| 有向图关系 | direct 67，indirect 67，unreachable 66 |
| 整数算术 | 负数 80，零 40，正数 80 |
| 时区排序 | 问最早 100，问最晚 100 |
| 受限程序执行 | 负数 80，零 40，正数 80 |
| 列表算法 | 结果存在 100，不存在 100 |
| 证据整合 | conflict 40，not_stated 40；queued/active/paused/closed 各 30 |

按固定生成顺序接受每个分层的前若干个合法、未重复、位于 Judge 分区的场景，直到全部配额满足；不足时报错，禁止静默降低配额、重复抽样或修改比例。The generation algorithm, original construction seed value and frozen evaluation-record bytes remain unchanged.为寻找罕见边界情况增加出题阶段生成上限，不占解题 Agent 的 10 万次合成额度。每次正式实验前冻结 manifest；这次更新发生在任何模型实验之前。

该分数代表这一固定分层任务上的准确率，不应解释成上游自然题目频率下的准确率。这样的配额用于减少高频默认答案的收益，并确保边界情况有足够覆盖。

## 教师使用参考策略

27B 教师用于数据合成和可选解释监督，最终标签仍由程序 oracle 决定。参考策略为：先程序生成合法题目，再根据学生在开发集上的弱项选择训练支持范围内的新难例，请教师补充解释，保留最终答案与 oracle 一致的输出。不能把开发题本身用于梯度训练。

教师每次输入、解释与答案均计费。例如平均每次请求总计 1000 tokens 时，200 万 token 仅够约 2000 次调用；不承诺逐条为 2 万题生成解释。这个例子不是实测长度。Agent 可以自行选择教师使用量、合成路线和筛选方式，仍可完全不使用教师。

`configs/teacher.json` 提供单卡纯文本参考配置：固定官方 Qwen3.8-27B snapshot、TP=1、总上下文 8192、小并发启动、冻结权重精度。原生思考内容也计入输出。运行时依赖、批量和吞吐由环境验证冻结，配置不代表已在 H100 跑通。

## 预算和控制组

以下是任务设计的上限，不是已实测性能：

| 项目 | 每个候选的上限或规则 |
| --- | --- |
| 监督训练状态 | 20000 个不同状态，含保留的种子；同场景改写不算新独立状态 |
| 提交合成校验的尝试 | 100000 个状态；拒绝、重复、替换和重采样计入 |
| 本地教师 token | 2000000，输入与输出都计；失败、重试、弃用、截断及任何 thinking token 也计 |
| 学生训练曝光 | 20000000 非 padding tokens；包含输入、每次重复训练、增强版本、解释与最终答案，即使输入不计算 loss 也计入 |
| 候选生产 | 单 H100 上最多 2 小时，含合成、选择、自评及训练；教师与学生必须分时加载 |
| Judge | 另有 30 分钟上限 |
| 整条轨迹 | 默认 24 小时，需要时另行记录延长至 48 小时；整个过程最多 16 次完成评分的 Judge 调用，含 B0/B1，延期不重置次数 |

总预算按研究过程的实际经过时间计算，含分析、合成、训练、评测与必要开销，不是要求用满的 GPU 时数。单轮目标约 2 小时，例如合成训练 75 分钟、Judge 30 分钟、分析与操作 15 分钟；10 轮约 20 小时，余下 4 小时作为缓冲。这是待实测校准的目标，不承诺 27B 教师一定能达到。按生产上限 2 小时、Judge 0.5 小时及 0.5 小时必要开销作保守规划，单轮约 3 小时，官方参考容量为 48/3=16 轮；默认 24 小时内不保证完成 10 轮。token 和时间先达到任一上限即停止。

B0 是原始 Base 在同一生成与解析协议下的结果，不需要先训练。B1 是固定程序数据＋固定 CE LoRA 训练控制；`configs/baseline.json` 和 `scripts/build_baseline.py` 固定其数据及训练配方。

B1 保留 1800 条训练种子，按固定领域顺序轮转补齐：布尔逻辑 2858 条，其余领域各 2857 条，共 20000 条。使用持续的 `random.Random(20260930)`；已满领域跳过，一次 builder 调用算一次 proposal，拒绝也推进同一 RNG。剔除开发/参考及已有训练重复，只接收训练哈希分区；最多 100000 次尝试。最终顺序是原种子文件顺序，再按新样本接受顺序。语料、来源清单与哈希可在 CPU 上逐字重建。

训练种子统一为 42，覆盖 Python、NumPy、PyTorch CPU/CUDA、LoRA 初始化与 dropout；dataloader/shuffle seed 也为 42。重放还须记录训练步数、实际非 padding token、软件和硬件版本。固定种子不等于跨 GPU/框架逐位一致。rank 16 等超参数只约束 B1，候选仍可选择其他训练方法。

`data/baseline/` 是配方可复现性的参考材料，不是免费附送的额外训练池。正式 B1 必须在 Work 重建并计时，或继承完整、可信的首次构建成本。B1 的训练后权重尚未生成。

每次候选从同一 Base 开始；恢复同一候选时继续累计预算，不能跨候选热启动已训练权重。`configs/budget.json` 固定数值上限，`scripts/budget_accounting.py` 实现下面的计费算术。

```text
候选计费生产时间
  = 本次实际 Work 经过时间
  + 所用缓存数据的历史生成与筛选时间（按唯一 receipt 及祖先集合计一次）

教师 token / proposal 次数
  = 本次全部 receipt（含失败、重试、丢弃）
  + 所用缓存数据的唯一历史 receipt 及祖先

整条轨迹时间
  = 实际经过时间，不重复累加继承的历史时间
```

本次 Work 从首个合成、选择或模型加载操作之前开始，计到最终 checkpoint 保存并停止生产进程，包含合成、筛选、教师/学生加载、自评及保存。当前生成成本已在本次经过时间里，不再加一次。历史 receipt 的时间必须排除已计入父 receipt 或另一 receipt 的重叠时间；沿父依赖追溯后按 ID 去重。

复用一批数据中的任意输出，继承整批生成与筛选成本及其失败尝试；不能只拿成功样本分摊出一个更低成本。同一批只计一次。固定公开的 1800 条种子是启动资产，无合成费用。旧候选的训练时间不转嫁到新候选，但其已训练权重也不可复用。

例如：本次 Work 用了 70 分钟，复用的唯一历史合成批次用了 20 分钟，则该候选计费 90 分钟；旧批次在整条研究轨迹中已实际发生，因此不会再向 24 小时总预算加 20 分钟。

CPU 计费函数只验证算术，不能证明传入的 receipt 可信。最终任务 runner 必须产生不可由候选自行声明的记录、校验语料来源并执行在线停止。共享 Work/Judge 环境的 root 权限限制仍然存在，不能声称完全防篡改。

## 评分与满分条件

每道题只检查最终答案的类型和值是否与 oracle 完全一致，正确为 1，错误为 0。解释文风、长度和推理步骤不另加分。每个领域在每种条件下各有 200 题，先计算各单元准确率，再等权平均：

```text
score = 100 × 0.5 × (七领域 ID 准确率平均 + 七领域结构变化准确率平均)
      = 100 × 正确题数 / 2800
```

**满分为 100 分，必须同时满足：**

1. All 2,800 runtime-held-out evaluation records are answered correctly, with 100% accuracy in each of the 14 domain-by-condition cells.
2. 每道题有格式有效且类型正确的最终答案，整个评测完整结束。
3. 候选遵守可修改范围、数据使用规则与计算预算。

不要求用某种训练方法，也不要求必须展示推理。相对 baseline 提升、运行更快或解释更好均不能补偿错误答案。满分是明确的评分终点，不是对预算内可达性的实测承诺。

| 情况 | 得分或处理 |
| --- | --- |
| 2800 题全部正确且候选合规 | 100，满分 |
| 2520 题正确 | 90 |
| 2799 题正确 | 约 99.9643，仍不是满分 |
| 某题缺少最终答案、格式错误或类型/值错误 | 该题 0，其余题正常计分 |
| 输出到 512-token 上限 | 最终行完整且有效则正常评分；没有有效最终行则该题 0 |
| 已确认超预算、泄漏或修改冻结组件 | 候选无效，不能取得满分或有效部分分 |
| 任务超时、模型无法加载、崩溃或评测未完成 | 不计有效分数，不编造成 0 准确率 |

正式 CPU 评分入口为 `scripts/judge_gate.py`。可信 Judge 启动器固定 dataset 和 manifest 的路径及文件承诺；入口检查 Judge 文件 SHA256、字节数、2800 个唯一 ID、14 组各 200 题，以及响应 ID 集合完全相同。缺题、重复、多余、替换 ID 或哈希不符均拒绝评分。通用开发集辅助函数只能用于诊断，不能代替正式入口。

评分入口接收每行 `{"id":"...","response":"..."}` 的输出；只返回聚合指标。即使数值为 100，外层仍需通过模型来源、预算和可修改范围检查后才认定合规满分。当前 CPU 实现明确返回 `eligibility_checked=false`，不会假装已经完成 GPU 和预算执行验证。

保留未四舍五入的分数用于比较，显示成“100.00”不能替代“全部正确”的满分判定。报告相对 B1 的提升、ID/结构变化宏平均、各领域准确率及格式有效率；这些辅助指标不改变主分数。

2800 个场景是独立计量单位。仅在噪声可能影响结论时，对候选和 B1 做分层、成对的场景级不确定性分析，并按需复跑训练。

## 已有证据与尚未执行的部分

本包已核验来源版本、生成器、原始划分、派生数据和文件哈希；`python3 scripts/materialize_data.py --check` 已通过逐字重建检查。正式 Judge 与所有公开数据之间的规范化精确输入重复为 0。各集的模板字符数在 manifest 中记录；这不是 tokenizer 的实际长度测量。数据构建不等于训练系统已运行。分层数据构建、B1 语料重建、严格 CPU 评分和缓存计费算术已实现。训练器配置适配、任意候选状态准入、可信 receipt 收集、标准 checkpoint/adapter 加载与模型生成、Harbor 环境及实际 H100 验证仍属于后续任务构建。自回归最多 512-token 的 Judge 耗时须重新实测，30 分钟是拟定上限。它们不能被描述为已通过验证。

官方提案审核不要求预先得到 baseline 分数或完整实验轨迹，但要求可追溯源码、资源、明确科学边界和比较协议。本文为这些内容提供完整技术定义；Contributor 姓名、邮箱和相关公开经验按要求留待补充。
